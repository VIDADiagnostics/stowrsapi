var _uploadId="";
var msggetStatus = document.getElementById("getStatus");
(function() {
let chunkCount = 0;
let chunkArray = []

var f = document.getElementById('f');
var msgid = document.getElementById("msg");



msgid.innerHTML="Starting Upload"
if (f.files.length)
  getFileCount();

f.addEventListener('change', getFileCount, false);


function getFileCount(e) {
  var fileCount = f.files.length;
  var file = f.files[0];
  var size = file.size;
  processFile("test");
  }

let count = 0;
function processFile(e) {
  var fileCount = f.files.length;
  let type = 0;
  chunkCount++;

send(f.files[0], fileCount, 0,e,f.files[0].name);
setTimeout(loop, 10000);

 function loop() {
  for(let i = 1 ; i<fileCount ; i++){
  chunkArray.push("started")
  var file = f.files[i];
       send(file, fileCount, i,e,file.name);
  }

  }
}

function send(piece,fileCount,count,uploadId,filename) {
  var username = document.getElementById("username").value;
  var password = document.getElementById("password").value;
  orgId = document.getElementById("orgId").value;
  projectId = document.getElementById("projId").value;
  endpoint = document.getElementById("endpoint").value;
  base64UP = btoa(username+":"+password);
  console.log(username)
  console.log(password)
  console.log(base64UP)
  var offset = Intl.DateTimeFormat().resolvedOptions().timeZone;
  console.log("offset",offset);
  var formdata = new FormData();
  var xhr1 = new XMLHttpRequest();
  xhr1.open('POST', endpoint+'/'+projectId+'/'+orgId+'/stowrs/studies', true);

  xhr1.setRequestHeader('Authorization', 'Basic '+base64UP );
  formdata.append('content', piece);
  formdata.append('timeZone', '89qw');


 xhr1.onreadystatechange = () => {
   if (xhr1.readyState === 4) {
   
      console.log("completeUpload Triggered",xhr1.response)
      
      
    }
  };
  xhr1.send(formdata);
}

})();

function getStatus(){

console.log("upload Id",_uploadId)

  var xhr = new XMLHttpRequest();
  xhr.open('POST', endpoint+'/'+projectId+'/'+orgId+'/stowrs/studies/uploadstatus', true);
  xhr.setRequestHeader("Content-Type", "application/json");
  xhr1.setRequestHeader('Authorization', 'Basic '+base64UP );
const json = {"uploadId":_uploadId};
   xhr.send(JSON.stringify(json));
   xhr.onreadystatechange = () => {
    if (xhr.readyState === 4) {
            console.log(xhr.response);  
            var obj = eval("(" + xhr.response + ')');
          var obj1 = eval("(" + obj.body + ')');  
      msggetStatus.innerHTML=obj1.status;

    }
  };
}

function getProjects(){

  var username = document.getElementById("username").value;
  var password = document.getElementById("password").value;
  var base64UP = btoa(username+":"+password);
  var endpoint = document.getElementById("endpoint").value;

    var xhr = new XMLHttpRequest();
    xhr.open('GET', endpoint+'/projects', true);
    xhr.setRequestHeader("Content-Type", "application/json");
    xhr.setRequestHeader('Authorization', 'Basic '+base64UP );
   
     xhr.send();
     xhr.onreadystatechange = () => {
      if (xhr.readyState === 4) {
              console.log(xhr.response);  
              var obj = eval("(" + xhr.response + ')');
          
        console.log("body",obj.body.projects[0].projectId)
        console.log("body",obj.body.projects[0].organizationId)
        console.log("body",obj.body.projects[0].projectName)

        document.getElementById("orgId").value = obj.body.projects[0].organizationId;
       document.getElementById("projId").value = obj.body.projects[0].projectId;
      
       document.getElementById("projName").innerHTML="Project Name :"+obj.body.projects[0].projectName;


  
      }
    };
  }